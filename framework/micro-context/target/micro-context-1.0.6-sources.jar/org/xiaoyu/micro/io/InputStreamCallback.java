package org.xiaoyu.micro.io;

import java.io.IOException;
import java.io.InputStream;

public interface InputStreamCallback<T> {

    T doWithInputStream(InputStream inputStream) throws IOException;
}
